package ar.org.poo.tp.irinaayala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooTpIrinaAyalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
