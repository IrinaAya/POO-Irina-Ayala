package ar.org.poo.tp.irinaayala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooTpIrinaAyalaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PooTpIrinaAyalaApplication.class, args);
	}

}
