package ar.org.poo.tp.irinaayala.entidades;

import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter
//extends marca la herencia
public class AutoNuevo extends Vehiculo{
    //un AutoNuevo siempre tiene Radio 
    public AutoNuevo(String color, String marca, String modelo, Radio radio) {
        super(color, marca, modelo);
        this.radio = radio;
    }
    //mostramos los datos de la clase AutoNuevo que extiende de la super clase Vehículo más la radio
    @Override
    public void mostrarDatos() {
    System.out.println("AutoNuevo - Marca: " + getMarca() + ", Modelo: " + getModelo() + ", Color: " + getColor());
    System.out.println(getRadio().mostrarDatos());
    }
    //informa el tipo de vehículo que es
    @Override
    public String tipoDeVehiculo() {
    return "Auto Nuevo";
    }
}
