package ar.org.poo.tp.irinaayala.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
//no existen instancias puras de vehículo
public abstract class Vehiculo {
    //atributos
    //un vehículo siempre tiene marca, color y modelo
    private String color;
    private String marca;
    private String modelo;
    protected Radio radio; 
    //un vehículo no siempre tiene precio
    private Double precio;

    //constructor
    //tenemos el constructor sin radio ya que en un principio no se agrega
    public Vehiculo(String color, String marca, String modelo) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
    }

    //método abstracto para mostrar los datos de cada vehículo 
    public abstract void mostrarDatos();

    //método abstracto para que cada subclase informe que tipo de vehículo es
    public abstract String tipoDeVehiculo();

    //método que si el vehículo no tiene radio(y la radio nueva no está asignada ya a otro vehículo) se la agrega
    public void agregarRadio(Radio nuevaRadio) {
        if (this.radio == null && nuevaRadio.getVehiculo() == null ) {
            this.radio = nuevaRadio;
            nuevaRadio.setVehiculo(this);
        }else{
            System.out.println("La Radio está en otro vehículo o ya tiene una");
        }
    } 

    //método para reemplazar Radio(a la vez de verificar que una radio no este en un mismo vehículo)
    public void setRadio(Radio nuevaRadio) {
        if(nuevaRadio.getVehiculo() == null){
            if (this.radio !=null){
                this.radio.setVehiculo(null);
            }
            this.radio=nuevaRadio;
            nuevaRadio.setVehiculo(this);
        }else{
            System.out.println("No se le puede asignar una misma radio a un vehículo diferente "
                         + "La radio " + nuevaRadio.getMarca() + " ya pertenece al vehículo: "
                         + nuevaRadio.getVehiculo().tipoDeVehiculo());                
    }


}
}
