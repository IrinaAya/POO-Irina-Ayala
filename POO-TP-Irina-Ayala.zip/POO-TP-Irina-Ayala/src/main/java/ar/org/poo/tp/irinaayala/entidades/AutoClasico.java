package ar.org.poo.tp.irinaayala.entidades;

import lombok.Getter;
import lombok.Setter;
@Getter 
@Setter  
//extends marca la herencia
public class AutoClasico extends Vehiculo{
    public AutoClasico(String color, String marca, String modelo) {
        super(color, marca, modelo);
    }
    //mostramos la información de la clase hija de vehículo, AutoClasico
    @Override
    public void mostrarDatos() {
        System.out.println("AutoClasico - Marca: " + getMarca() + ", Modelo: " + getModelo() + ", Color: " + getColor());
        //condición si tiene radio informa sus datos, si no tiene lo informa también 
        if (radio != null) {
            System.out.println(radio.mostrarDatos());
        } else {
            System.out.println("No tiene radio.");
        }
    }

    //informa el tipo de vehículo
    @Override
    public String tipoDeVehiculo() {
        return "Auto Clásico";
    }
}
