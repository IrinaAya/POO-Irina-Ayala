package ar.org.poo.tp.irinaayala.test;
import ar.org.poo.tp.irinaayala.entidades.Colectivo;
import ar.org.poo.tp.irinaayala.entidades.Radio;
import ar.org.poo.tp.irinaayala.entidades.AutoClasico;
import ar.org.poo.tp.irinaayala.entidades.AutoNuevo;

public class TestVehiculo {
    public static void main(String[] args) {
    //creamos objetos auto y radio
    Radio radio1 = new Radio("XBTQD", 60);
    Radio radio2 = new Radio("Oregon", 200);
    Radio radio3 = new Radio("Nakamichi", 50);
    Radio radio4 = new Radio("J520", 800);
    //autoNuevo siempre tiene Radio
    AutoNuevo auto1 = new AutoNuevo("Blanco", "Mercedez-Benz", "EQS", radio1);
    //autoclasico inicialmente no tiene radio
    AutoClasico auto2 = new AutoClasico("Rojo", "Jaguar", "E-Type");
    //colectivo tampoco tiene radio
    Colectivo auto3 = new Colectivo("Celeste", "Volvo", "Metalpar");
    //datos de AutoNuevo
    auto1.mostrarDatos();
    //cambiamos radio a AutoNuevo 
    System.out.println("Cambiamos Radio a AutoNuevo:");
    auto1.setRadio(radio4);
    auto1.mostrarDatos();
    System.out.println();
    //mostramos AutoClasico 
    auto2.mostrarDatos();
    auto2.agregarRadio(radio2);
    //le agregamos una Radio
    System.out.println("Agregamos radio:");
    auto2.mostrarDatos();
    System.out.println();
    //datos Colectivo 
    auto3.mostrarDatos();
    auto3.agregarRadio(radio3);
    //agregamos Radio 
    System.out.println("Agregamos radio:");
    auto3.mostrarDatos();
    //----------------------------------------------------------------
    //intentamos poner una Radio que ya está asignada a un vehículo
    System.out.println();
    System.out.println("Ponengamos una misma radio en dos vehículos: ");
    auto2.setRadio(radio3); 
    
    }
}

